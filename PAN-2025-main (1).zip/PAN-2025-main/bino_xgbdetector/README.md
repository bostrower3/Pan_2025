To Build a container:

docker build --no-cache -t bino_xgbdetector -f Dockerfile .

To Run a Container :

docker run --rm -v "C:\Users\poona\Desktop\test\input_data:/app/input"  -v "C:\Users\poona\Desktop\test\output_data:/app/output" bino_xgbdetector:latest --input_file /app/input/input.jsonl --output_file /app/output/output.jsonl
