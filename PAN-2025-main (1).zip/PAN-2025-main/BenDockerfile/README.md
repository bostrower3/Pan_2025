doesn't include tokenizer folder path or detector_model.pth
