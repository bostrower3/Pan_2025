import argparse
import json
import torch
from transformers import RobertaForSequenceClassification
from transformers import RobertaTokenizer

def load_tokenizer():
    return RobertaTokenizer.from_pretrained("tokenizer")

def load_model():
    #checkpoint = torch.load("detector_model.pth", map_location="cpu")
    model = RobertaForSequenceClassification.from_pretrained('roberta-large', num_labels=2).to('cpu')
    model.load_state_dict(torch.load("detector_model.pth", map_location="cpu"))
    model.eval()
    return model


def predict(text, model, tokenizer):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True)
    with torch.no_grad():
        logits = model(**inputs).logits
        return torch.argmax(logits, dim=-1).item()


def main(args):
    model = load_model()
    tokenizer = load_tokenizer()

    with open(args.input_file, 'r') as fin, open(args.output_file, 'w') as fout:
        for line in fin:
            entry = json.loads(line)
            pred = predict(entry["text"], model, tokenizer)
            fout.write(json.dumps({"id": entry["id"], "prediction": pred}) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", required=True)
    parser.add_argument("--output_file", default="output.jsonl")
    args = parser.parse_args()
    main(args)
