Build : 
docker build -t tocsin-ai-detector .

Run :
docker run --rm -it -v "C:/output_folder:/app/output" -v "C:/input/input.jsonl:/app/input_file" tocsin-ai-detector python main.py /app/input_file /app/output


